import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { privateDirectory, writePrivate } from './local-data.mjs';

const dir = path.dirname(fileURLToPath(import.meta.url)),
  bundle = path.dirname(dir),
  catalog = JSON.parse(fs.readFileSync(path.join(bundle, 'catalog.json'))),
  hash = (x) => crypto.createHash('sha256').update(x).digest('hex'),
  quote = (x) => "'" + x.replaceAll("'", "'\\''") + "'";

function rootIdentity(root, expected) {
  const st = fs.lstatSync(root);
  if (st.isSymbolicLink() || !st.isDirectory() || fs.realpathSync(root) !== root)
    throw Error('Installation root changed or is symbolic');
  const value = { dev: st.dev, ino: st.ino };
  if (expected && (value.dev !== expected.dev || value.ino !== expected.ino))
    throw Error('Installation root identity changed since preview');
  return value;
}

function safe(root, relative) {
  rootIdentity(root);
  if (path.isAbsolute(relative) || relative.split(/[\\/]/).includes('..'))
    throw Error('Invalid installation path');
  let dest = root;
  for (const p of relative.split('/')) {
    dest = path.join(dest, p);
    try {
      const st = fs.lstatSync(dest);
      if (st.isSymbolicLink()) throw Error('Refusing symbolic-link target: ' + relative);
      if (st.isFile() && st.nlink !== 1) throw Error('Refusing hardlinked installation target');
      if (!st.isFile() && !st.isDirectory()) throw Error('Refusing nonregular installation target');
    } catch (e) {
      if (e.code !== 'ENOENT') throw e;
    }
  }
  return dest;
}

const read = (f) => (fs.existsSync(f) ? fs.readFileSync(f, 'utf8') : null);

export function planInstall({ claudeHome, selected = [] }) {
  if (!claudeHome || !fs.existsSync(claudeHome))
    throw Error('Create/choose the Claude user directory first');
  if (!Array.isArray(selected) || selected.some((id) => !catalog.some((c) => c.id === id)))
    throw Error('Choose known packages');
  const root = fs.realpathSync(claudeHome),
    identity = rootIdentity(root),
    stateFile = safe(root, 'context-audit-install/state.json'),
    old = read(stateFile),
    prior = old ? JSON.parse(old) : { selected: [], hashes: {} },
    ids = [...new Set([...prior.selected, ...selected])].sort(),
    files = [];

  const add = (relative, content, merge = false) => {
    const file = safe(root, relative),
      before = read(file);
    if (
      before !== null &&
      before !== content &&
      !merge &&
      prior.hashes?.[relative] !== hash(before)
    )
      throw Error('Existing file differs; review before replacing: ' + relative);
    files.push({ relative, before, after: content });
  };

  const copy = (folder, relative = '') => {
    for (const e of fs.readdirSync(folder, { withFileTypes: true })) {
      if (e.isSymbolicLink()) throw Error('Invalid bundle symlink');
      const part = relative ? relative + '/' + e.name : e.name;
      if (e.isDirectory()) copy(path.join(folder, e.name), part);
      else if (e.isFile())
        add('skills/context-audit/' + part, fs.readFileSync(path.join(folder, e.name), 'utf8'));
    }
  };

  copy(bundle);
  const settingsFile = safe(root, 'settings.json'),
    settingsText = read(settingsFile),
    config = settingsText ? JSON.parse(settingsText) : {};
  if (
    config.hooks !== undefined &&
    (!config.hooks || typeof config.hooks !== 'object' || Array.isArray(config.hooks))
  )
    throw Error('Unrecognized hooks configuration');
  config.hooks ??= {};

  const addHook = (event, mode, matcher) => {
    const command =
        'node ' + quote(path.join(root, 'skills/context-audit/scripts/hooks.mjs')) + ' ' + mode,
      entry = {
        ...(matcher ? { matcher } : {}),
        hooks: [{ type: 'command', command, timeout: 10 }],
      };
    if (config.hooks[event] !== undefined && !Array.isArray(config.hooks[event]))
      throw Error('Unrecognized ' + event + ' hooks');
    config.hooks[event] ??= [];
    if (!config.hooks[event].some((e) => (e.hooks || []).some((h) => h.command === command)))
      config.hooks[event].push(entry);
  };

  if (ids.includes('continuity')) {
    addHook('SessionStart', 'continuity', 'startup|resume|compact');
    addHook('PreCompact', 'continuity');
  }
  if (ids.includes('results')) addHook('PostToolUse', 'results', '^Bash$');
  if (ids.includes('evidence')) addHook('PostToolUse', 'evidence');
  if (ids.includes('measurement'))
    for (const event of ['SessionStart', 'PreCompact', 'SessionEnd']) addHook(event, 'measurement');
  if (ids.some((id) => ['continuity', 'results', 'evidence', 'measurement'].includes(id)))
    add('settings.json', JSON.stringify(config, null, 2) + '\n', true);
  if (ids.includes('workflow'))
    for (const [id, model, purpose] of [
      [
        'evidence',
        'haiku',
        'Collect scoped source-linked evidence; do not modify files or decide final QA acceptance.',
      ],
      [
        'review',
        'sonnet',
        'Review a bounded hypothesis/test packet; identify missing evidence and escalation needs.',
      ],
    ])
      add(
        'agents/context-audit-' + id + '.md',
        '---\nname: context-audit-' +
          id +
          '\ndescription: ' +
          purpose +
          '\nmodel: ' +
          model +
          '\ntools: Read, Glob, Grep\n---\n' +
          purpose +
          '\nRead only the assigned sources. Return the report contract from ' +
          path.join(root, 'skills/context-audit/references/workflow.md') +
          ('. Keep the report under12,000 characters. Escalate ambiguity, missing evidence or scope ' +
            'overflow to the parent. Do not assert unrun checks passed.\n'),
      );
  const hashes = Object.fromEntries(
    files.filter((f) => f.relative !== 'settings.json').map((f) => [f.relative, hash(f.after)]),
  );
  add(
    'context-audit-install/state.json',
    JSON.stringify({ schema: 1, selected: ids, hashes }, null, 2) + '\n',
    true,
  );
  rootIdentity(root, identity);
  return {
    schema: 1,
    root,
    rootIdentity: identity,
    selected: ids,
    files,
    scope:
      'Global generic integration only; project checkpoints/evidence stay under active cwd. ' +
      'POSIX command hooks; validate installed native runtime.',
  };
}

export function applyPlan(plan) {
  if (!plan.rootIdentity) throw Error('Preview lacks root identity; generate a fresh preview');
  rootIdentity(plan.root, plan.rootIdentity);
  for (const f of plan.files) {
    const target = safe(plan.root, f.relative);
    if (read(target) !== f.before) throw Error('File changed since preview: ' + f.relative);
  }
  const changed = plan.files.filter((f) => f.before !== f.after),
    id = Date.now() + '-' + crypto.randomUUID(),
    manifest = safe(plan.root, 'context-audit-install/manifests/' + id + '.json'),
    applied = [];
  try {
    privateDirectory(safe(plan.root, 'context-audit-install'), true);
    privateDirectory(path.dirname(manifest), true);
    for (const f of changed) {
      const target = safe(plan.root, f.relative);
      fs.mkdirSync(path.dirname(target), { recursive: true });
      fs.writeFileSync(target, f.after, { mode: 0o600 });
      applied.push(f);
    }
    const data = {
      schema: 1,
      root: plan.root,
      rootIdentity: plan.rootIdentity,
      selected: plan.selected,
      files: changed.map((f) => ({ ...f, afterHash: hash(f.after) })),
    };
    writePrivate(manifest, JSON.stringify(data, null, 2) + '\n');
    return { path: manifest, changed: changed.map((f) => f.relative) };
  } catch (e) {
    for (const f of applied.reverse()) {
      const p = safe(plan.root, f.relative);
      f.before === null ? fs.rmSync(p) : fs.writeFileSync(p, f.before, { mode: 0o600 });
    }
    throw e;
  }
}

export function rollback(manifest) {
  const m = JSON.parse(fs.readFileSync(manifest)),
    root = m.root;
  if (!m.rootIdentity) throw Error('Manifest lacks installation root identity');
  rootIdentity(root, m.rootIdentity);
  if (m.schema !== 1 || !Array.isArray(m.files)) throw Error('Invalid manifest');
  for (const f of m.files) {
    const text = read(safe(root, f.relative));
    if (text === null || hash(text) !== f.afterHash)
      throw Error('Refusing rollback: file changed ' + f.relative);
  }
  for (const f of [...m.files].reverse()) {
    const target = safe(root, f.relative);
    f.before === null ? fs.rmSync(target) : fs.writeFileSync(target, f.before, { mode: 0o600 });
  }
  return { restored: m.files.map((f) => f.relative) };
}
