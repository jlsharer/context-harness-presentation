# Acceptance contract — incident-recovery

Same contract for every execution approach. Existing context, README.md, package.json, TASK.md, ACCEPTANCE.md and original test/*.test.mjs are frozen; do not change them. Edit src/ and add test/added-*.test.mjs plus the deliverables below. No dependencies or network.

## Functional gates
- One committed tenant/key identity and one delivery for concurrent duplicates.
- Pre-commit failure does not count; post-commit timeout retains durable identity and retry repairs pending delivery.
- Repeated recovery across restart does not duplicate effects; distinct keys make independent progress.
- Existing API, error and tenant behavior remain compatible.

## Required deliverables
- plan.md before source edits: concise diagnosis/requirements, affected interfaces, implementation sequence and validation risks. Timing is reported only if observed; its content is required.
- analysis.json with {requirements:[{id,anchors:[...],codePaths:[...],testPaths:[...]}],rejectedHistorical:[...],uncertainty:[...],observedMechanisms:[...]}. Required requirement IDs and source anchors: {"atomic-order":["API-2","STORAGE-1","INCIDENT-1"],"commit-count":["STORAGE-2","INCIDENT-2"],"delivery-recovery":["DELIVERY-1","STORAGE-3","INCIDENT-3"],"tenant-isolation":["SECURITY-2"]}. Every required anchor must appear on its corresponding row; codePaths must name actual src/ files and testPaths actual added test files. These are machine-checkable traceability facts, not a free-form reasoning-quality score.
- rejectedHistorical includes ADR-OLD-1. uncertainty includes production-impact-unmeasured. observedMechanisms identifies the fixture mechanisms using IDs non-atomic-key-check, count-before-commit, replay-duplicates-effect. Explain the causal sequence in summary.md, including the lost-acknowledgement gap.
- summary.md: changes, evidence-backed explanation, compatibility/migration notes and remaining risks.
- validation.json: {commands:[{command,exitCode}],limitations:[...]}; record actual executed checks. Include npm test.
- Add test/added-*.test.mjs. They must pass on your result and expose at least one task defect/missing behavior on the untouched starter. Do not edit existing regressions.

External scoring runs frozen original regressions, task-specific behavioral cases, unchanged-context checks, artifact/traceability checks and the added-test baseline differential. All gates must pass for acceptance. Both failure and partial success remain reportable. Public requirements are complete; exact test implementations/reference solutions are not participant inputs.
