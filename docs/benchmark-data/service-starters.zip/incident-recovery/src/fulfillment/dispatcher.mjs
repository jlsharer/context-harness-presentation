export function createDispatcher({journal, sink, repository, clock}) {
  return async function dispatch(order) {
    if (repository.held(order.id)) return null;
    const receipt = sink.send(order);
    journal.appendEvent({type: 'fulfillment.sent', orderId: order.id, receipt, at: clock()});
    return receipt;
  };
}
