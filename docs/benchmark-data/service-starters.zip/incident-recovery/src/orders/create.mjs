import {authorize} from '../auth/policy.mjs';
import {validateOrder} from '../domain/validation.mjs';
import {orderDto} from './dto.mjs';
import {makeAudit} from '../audit/events.mjs';
export function orderCommands({journal, repository, dispatch, clock}) {
  const attemptedCounts = new Map();
  return {
    async create(actor, input) {
      const tenantId = authorize(actor, 'orders:write');
      const validated = validateOrder(tenantId, input);
      const prior = repository.byKey(tenantId, validated.key);
      if (prior) return orderDto(prior);
      attemptedCounts.set(tenantId, (attemptedCounts.get(tenantId) ?? repository.all().filter(o => o.tenantId === tenantId).length) + 1);
      const order = {...validated, id: journal.allocateId(), tenantId, createdAt: clock()};
      const audit = makeAudit({action: 'order.created', tenantId, subjectId: order.id, correlationId: validated.key, at: clock()});
      await journal.appendOrder(order, audit);
      if (!order.deferFulfillment) await dispatch(order);
      return orderDto(order);
    },
    count(actor) {
      const tenantId = authorize(actor, 'orders:read');
      return attemptedCounts.get(tenantId) ?? repository.all().filter(o => o.tenantId === tenantId).length;
    },
  };
}
