# Dispatch Ledger Service

Offline synthetic order-to-fulfillment service for reproducible agent benchmarking. Node24, no external dependencies or services. `npm test` runs the supplied regression tests. Start with `TASK.md`, `ACCEPTANCE.md`, and `context/00-index.md`.

- `src/orders/`: creation, query, DTO and durable projection.
- `src/storage/`: shared journal and deterministic failure hooks.
- `src/fulfillment/`: downstream idempotency, recovery and holds.
- `src/billing/`: invoice export and pagination.
- `src/auth/`, `src/audit/`, `src/domain/`: permissions, audit schema and validation/money.
- `src/api/`: thin in-process HTTP-shaped routes.
- `test/`: existing regressions; add `test/added-*.test.mjs` for this change.
- `context/`: current contracts, superseded decisions, incident evidence and frozen external-style references.

The journal and delivery sink intentionally persist across new service instances. They are local stand-ins for real service boundaries, not claims of database or network realism.
