# Acceptance contract — holds-invoices

Same contract for every execution approach. Existing context, README.md, package.json, TASK.md, ACCEPTANCE.md and original test/*.test.mjs are frozen; do not change them. Edit src/ and add test/added-*.test.mjs plus the deliverables below. No dependencies or network.

## Functional gates
- Holds/releases persist, are idempotent, authorize before mutation and prevent delivery while held, including restart.
- Invoice export includes only committed same-tenant orders; half-up integer arithmetic, stable offset pagination and empty-page semantics.
- Shared audit schema records successful transitions/exports; failures and no-op transitions create no success events.
- Existing order/retry/recovery/API behavior remains compatible.

## Required deliverables
- plan.md before source edits: concise diagnosis/requirements, affected interfaces, implementation sequence and validation risks. Timing is reported only if observed; its content is required.
- analysis.json with {requirements:[{id,anchors:[...],codePaths:[...],testPaths:[...]}],rejectedHistorical:[...],uncertainty:[...]}. Required requirement IDs and source anchors: {"holds":["HOLDS-1","HOLDS-2"],"invoices":["INVOICE-1","INVOICE-2","INVOICE-3"],"authorization":["SECURITY-1","SECURITY-2"],"audit":["AUDIT-1","AUDIT-2"],"compatibility":["API-2","STORAGE-2","DELIVERY-1"]}. Every required anchor must appear on its corresponding row; codePaths must name actual src/ files and testPaths actual added test files. These are machine-checkable traceability facts, not a free-form reasoning-quality score.
- rejectedHistorical includes ADR-OLD-2. uncertainty includes production-impact-unmeasured. 
- summary.md: changes, evidence-backed explanation, compatibility/migration notes and remaining risks.
- validation.json: {commands:[{command,exitCode}],limitations:[...]}; record actual executed checks. Include npm test.
- Add test/added-*.test.mjs. They must pass on your result and expose at least one task defect/missing behavior on the untouched starter. Do not edit existing regressions.

External scoring runs frozen original regressions, task-specific behavioral cases, unchanged-context checks, artifact/traceability checks and the added-test baseline differential. All gates must pass for acceptance. Both failure and partial success remain reportable. Public requirements are complete; exact test implementations/reference solutions are not participant inputs.
