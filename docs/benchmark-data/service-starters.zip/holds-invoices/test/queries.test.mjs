import test from 'node:test';import assert from 'node:assert/strict';
import {createService} from '../src/service.mjs';import {createJournal} from '../src/storage/journal.mjs';
import {createSink} from '../src/fulfillment/sink.mjs';import {calculateTotals} from '../src/domain/money.mjs';
import {createApi} from '../src/api/router.mjs';import {page} from '../src/billing/pagination.mjs';
const actor={tenantId:'north',permissions:['orders:read','orders:write','fulfillment:write','billing:read']};
const input=(key='k')=>({key,items:[{sku:'book',quantity:2,unitCents:125}],taxBps:800});
test('queries sort IDs, enforce tenant identity and expose no mutable state',async()=>{const s=createService();const a=await s.createOrder(actor,input('a'));await s.createOrder(actor,input('b'));const results=s.listOrders(actor);results[0].key='tampered';assert.equal(s.getOrder(actor,a.id).key,'a');assert.equal(results.length,2);assert.throws(()=>s.getOrder({...actor,tenantId:'south'},a.id),e=>e.code==='NOT_FOUND');});
