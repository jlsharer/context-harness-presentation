import test from 'node:test';import assert from 'node:assert/strict';
import {createService} from '../src/service.mjs';import {createJournal} from '../src/storage/journal.mjs';
import {createSink} from '../src/fulfillment/sink.mjs';import {calculateTotals} from '../src/domain/money.mjs';
import {createApi} from '../src/api/router.mjs';import {page} from '../src/billing/pagination.mjs';
const actor={tenantId:'north',permissions:['orders:read','orders:write','fulfillment:write','billing:read']};
const input=(key='k')=>({key,items:[{sku:'book',quantity:2,unitCents:125}],taxBps:800});
test('happy path order and sequential same-key retry preserve public shape',async()=>{const s=createService();const a=await s.createOrder(actor,input());const b=await s.createOrder(actor,input());assert.deepEqual(a,b);assert.deepEqual(Object.keys(a).sort(),['createdAt','id','key','status','tenantId','totalCents']);assert.equal(a.totalCents,270);assert.equal(s.countOrders(actor),1);});
