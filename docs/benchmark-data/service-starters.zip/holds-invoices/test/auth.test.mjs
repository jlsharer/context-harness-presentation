import test from 'node:test';import assert from 'node:assert/strict';
import {createService} from '../src/service.mjs';import {createJournal} from '../src/storage/journal.mjs';
import {createSink} from '../src/fulfillment/sink.mjs';import {calculateTotals} from '../src/domain/money.mjs';
import {createApi} from '../src/api/router.mjs';import {page} from '../src/billing/pagination.mjs';
const actor={tenantId:'north',permissions:['orders:read','orders:write','fulfillment:write','billing:read']};
const input=(key='k')=>({key,items:[{sku:'book',quantity:2,unitCents:125}],taxBps:800});
test('missing permission and malformed input cannot create orders',async()=>{const s=createService();await assert.rejects(s.createOrder({...actor,permissions:[]},input()),e=>e.code==='FORBIDDEN');await assert.rejects(s.createOrder(actor,{...input(),items:[]}),e=>e.code==='INVALID');assert.equal(s.countOrders(actor),0);});
