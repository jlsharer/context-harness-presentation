import test from 'node:test';import assert from 'node:assert/strict';
import {createService} from '../src/service.mjs';import {createJournal} from '../src/storage/journal.mjs';
import {createSink} from '../src/fulfillment/sink.mjs';import {calculateTotals} from '../src/domain/money.mjs';
import {createApi} from '../src/api/router.mjs';import {page} from '../src/billing/pagination.mjs';
const actor={tenantId:'north',permissions:['orders:read','orders:write','fulfillment:write','billing:read']};
const input=(key='k')=>({key,items:[{sku:'book',quantity:2,unitCents:125}],taxBps:800});
test('page boundaries and bad cursors are stable',()=>{assert.deepEqual(page([1,2,3],0,2),{items:[1,2],nextCursor:2});assert.deepEqual(page([1,2,3],2,2),{items:[3],nextCursor:null});assert.throws(()=>page([],0,0));assert.throws(()=>page([],-1,2));});
