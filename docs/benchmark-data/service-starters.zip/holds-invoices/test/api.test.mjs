import test from 'node:test';import assert from 'node:assert/strict';
import {createService} from '../src/service.mjs';import {createJournal} from '../src/storage/journal.mjs';
import {createSink} from '../src/fulfillment/sink.mjs';import {calculateTotals} from '../src/domain/money.mjs';
import {createApi} from '../src/api/router.mjs';import {page} from '../src/billing/pagination.mjs';
const actor={tenantId:'north',permissions:['orders:read','orders:write','fulfillment:write','billing:read']};
const input=(key='k')=>({key,items:[{sku:'book',quantity:2,unitCents:125}],taxBps:800});
test('API routes preserve success, denial, invalid input and missing semantics',async()=>{const api=createApi(createService());const a=await api.handle({method:'POST',path:'/orders',actor,body:input()});assert.equal(a.status,201);assert.equal((await api.handle({method:'GET',path:'/orders',actor})).body.items.length,1);assert.equal((await api.handle({method:'POST',path:'/orders',actor:{...actor,permissions:[]},body:input()})).status,403);assert.equal((await api.handle({method:'GET',path:'/absent',actor})).status,404);});
