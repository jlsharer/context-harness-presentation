import test from 'node:test';import assert from 'node:assert/strict';
import {createService} from '../src/service.mjs';import {createJournal} from '../src/storage/journal.mjs';
import {createSink} from '../src/fulfillment/sink.mjs';import {calculateTotals} from '../src/domain/money.mjs';
import {createApi} from '../src/api/router.mjs';import {page} from '../src/billing/pagination.mjs';
const actor={tenantId:'north',permissions:['orders:read','orders:write','fulfillment:write','billing:read']};
const input=(key='k')=>({key,items:[{sku:'book',quantity:2,unitCents:125}],taxBps:800});
test('committed creates emit tenant-scoped successful audit facts',async()=>{const s=createService();await s.createOrder(actor,input());const events=s.auditEvents(actor);assert.equal(events.length,1);assert.equal(events[0].action,'order.created');assert.equal(events[0].outcome,'success');assert.equal(events[0].correlationId,'k');assert.deepEqual(s.auditEvents({...actor,tenantId:'south'}),[]);});
