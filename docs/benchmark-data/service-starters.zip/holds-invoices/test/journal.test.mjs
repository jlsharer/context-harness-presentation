import test from 'node:test';import assert from 'node:assert/strict';
import {createService} from '../src/service.mjs';import {createJournal} from '../src/storage/journal.mjs';
import {createSink} from '../src/fulfillment/sink.mjs';import {calculateTotals} from '../src/domain/money.mjs';
import {createApi} from '../src/api/router.mjs';import {page} from '../src/billing/pagination.mjs';
const actor={tenantId:'north',permissions:['orders:read','orders:write','fulfillment:write','billing:read']};
const input=(key='k')=>({key,items:[{sku:'book',quantity:2,unitCents:125}],taxBps:800});
test('journal atomic primitive returns first committed record and clones reads',async()=>{const j=createJournal();const a={id:'1',tenantId:'north',key:'x'},b={...a,id:'2'};await j.commitOrder(a);assert.equal((await j.commitOrder(b)).id,'1');const rows=j.events();rows[0].order.key='bad';assert.equal(j.findOrder('north','x').key,'x');assert.equal(j.events().length,1);});
