import test from 'node:test';import assert from 'node:assert/strict';
import {createService} from '../src/service.mjs';import {createJournal} from '../src/storage/journal.mjs';
import {createSink} from '../src/fulfillment/sink.mjs';import {calculateTotals} from '../src/domain/money.mjs';
import {createApi} from '../src/api/router.mjs';import {page} from '../src/billing/pagination.mjs';
const actor={tenantId:'north',permissions:['orders:read','orders:write','fulfillment:write','billing:read']};
const input=(key='k')=>({key,items:[{sku:'book',quantity:2,unitCents:125}],taxBps:800});
test('money validates units and computes a non-tie total',()=>{assert.deepEqual(calculateTotals([{sku:'a',quantity:2,unitCents:125}],800),{subtotalCents:250,taxCents:20,totalCents:270});assert.throws(()=>calculateTotals([{sku:'a',quantity:0,unitCents:125}]),e=>e.code==='INVALID');assert.throws(()=>calculateTotals([{sku:'a',quantity:1,unitCents:1.2}]),e=>e.code==='INVALID');});
