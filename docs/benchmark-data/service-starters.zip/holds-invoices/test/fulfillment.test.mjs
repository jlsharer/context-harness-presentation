import test from 'node:test';import assert from 'node:assert/strict';
import {createService} from '../src/service.mjs';import {createJournal} from '../src/storage/journal.mjs';
import {createSink} from '../src/fulfillment/sink.mjs';import {calculateTotals} from '../src/domain/money.mjs';
import {createApi} from '../src/api/router.mjs';import {page} from '../src/billing/pagination.mjs';
const actor={tenantId:'north',permissions:['orders:read','orders:write','fulfillment:write','billing:read']};
const input=(key='k')=>({key,items:[{sku:'book',quantity:2,unitCents:125}],taxBps:800});
test('default create sends one effect and deferred create waits for recovery',async()=>{const sink=createSink(),s=createService({sink});await s.createOrder(actor,input());assert.equal(sink.receipts().length,1);const second=createService({sink:createSink()});await second.createOrder(actor,{...input(),deferFulfillment:true});assert.equal(second.listOrders(actor).length,1);assert.equal((await second.recover(actor)).length,1);});
