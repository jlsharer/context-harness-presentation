# ADR-OLD-1 — retry assumption, 2025-06-01
Status: superseded; retained to explain the old implementation.

An early client assumed any timeout meant storage rolled back. The service counted accepted attempts and relied on an in-memory key lookup. Recovery was assumed to run once.

This ADR is not authoritative. Current STORAGE-1/2/3, API-2/3 and DELIVERY-1/2 replace these assumptions. Do not disable retries to hide a duplicated effect.
