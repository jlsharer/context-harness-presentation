# Current invoice export — 2026-10-20
Owner: billing team. Status: authoritative feature requirements.

## INVOICE-1
exportInvoices(actor,{cursor?:0,limit?:20,correlationId}) requires billing:read and returns {items,nextCursor}. Each item is {orderId,tenantId,subtotalCents,taxCents,totalCents}. Include only that tenant's committed orders, sorted by stable order ID. Invoice totals are recomputed from committed line items and taxBps.

## INVOICE-2
Integer minor units only. subtotal=sum(quantity*unitCents). Tax is rounded half up once per order: floor((subtotal*taxBps+5000)/10000). E.g.101c at5000bps→51c tax,152c total;1c→1c tax,2c total. No floating currency conversion.

## INVOICE-3
Cursor is a nonnegative integer offset; limit is an integer1–100. nextCursor is null when exhausted, including empty pages. Invalid pagination is INVALID/400, with no success audit. The snapshot is static within each acceptance pagination case; concurrent inserts across pages are outside this task. Every valid export invocation emits one audit event; correlation ID identifies that invocation but is not a deduplication key.
