# Frozen delivery provider contract
Synthetic external-style reference, version 2, 2026-10-20.

## DELIVERY-1
createSink() represents a durable external provider retained across service restarts. send(order) creates a new receipt every time. sendOnce(idempotencyKey,order) returns the first receipt for that key without repeating delivery. Bind the key to tenant and committed order identity; do not use an attempt ID.

## DELIVERY-2
Receipt creation is synchronous in this fixture. The boundary stands in for a provider idempotency guarantee, not a distributed transaction with the journal. Repeating recovery and repairing a missing local fulfillment.sent record must not create another external receipt. No production durability or network throughput is inferred.
