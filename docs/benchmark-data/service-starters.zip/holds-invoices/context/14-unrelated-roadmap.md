# 2027 roadmap note
Status: draft; not a requirement for these tasks.

## ROADMAP-1
Possible future work: tracking integration, subscriptions, currency conversion, geographic routing and a browser dashboard. Do not implement these in this task. This document deliberately provides plausible but irrelevant context.
