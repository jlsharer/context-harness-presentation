# Shared audit schema — 2026-10-20
Owner: platform team. Status: authoritative.

## AUDIT-1
Successful hold.created, hold.released and invoice.exported actions emit {id,action,tenantId,subjectId,correlationId,outcome:'success',at}. Subject is the order ID for a transition and 'invoices' for export. at comes from the injected clock. Retain existing order.created behavior.

## AUDIT-2
Transition and its audit fact are one durable event. No-op holds/releases do not append another event. Failed authorization, validation or nonexistent orders cannot produce success audit. auditEvents(actor) remains tenant scoped. No credentials or request bodies belong in audit facts.
