# Integer-money reference
Synthetic external-style reference, version1, frozen2026-10-20.

## MONEY-1
A basis point is1/10000. Keep integer cents throughout multiplication and addition; ensure intermediate arithmetic stays within Number.MAX_SAFE_INTEGER. Round tax once per order using the current invoice contract. Signed values, discounts, exchange rates and refunds are outside this fixture.

## MONEY-2
Line quantities1–10000, unitCents0–1000000, taxBps0–10000, at most100 line items. Reject a calculation whose intermediate rounded numerator is not a safe integer. These bounds are validation rules, not measured workloads.
