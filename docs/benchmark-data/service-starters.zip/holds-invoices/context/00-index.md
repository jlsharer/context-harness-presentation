# Context map and authority
Synthetic, frozen benchmark evidence. No document describes an actual company incident.

## AUTHORITY-1
Use current contracts and requirements dated 2026-10-20 over historical ADRs. Incident observations establish only the fixture mechanism, not production frequency or financial impact. Historical documents remain available to explain misleading assumptions. No live web or MCP lookup is needed.

Read current requirements, trace relevant code, then use incident evidence to resolve a causal hypothesis. Do not alter context files. The service baseline is intentionally incomplete for the task; the documents are the requirements.

Internal nodes: API, storage, security, workflow, audit, incident logs and historical decisions. External-style nodes: the frozen delivery-provider contract and integer-money guide, supplied locally to avoid time-dependent retrieval.
