# Incident evidence — synthetic reproduction INC-42
Observed in deterministic fixture; not production telemetry.

## INCIDENT-1
Two requests for north:k both read an absent projection before either persistence promise resolves. Separate generated IDs are observed in committed events. A sequential retry test did not reveal this interleaving.

## INCIDENT-2
A before-commit timeout left no order.committed event. The active service nevertheless reported one successful order. A later retry increased the reported count again.

## INCIDENT-3
An after-commit timeout left order.committed present but no fulfillment.sent record. The retry returned the cached/projected order without completing delivery. Restart recovery later produced repeated provider receipts because it used a non-idempotent dispatch surface.

## INCIDENT-4
The evidence establishes local causal mechanisms. It does not establish production impact, request frequency, monetary losses or provider outage rates. Preserve this uncertainty explicitly.
