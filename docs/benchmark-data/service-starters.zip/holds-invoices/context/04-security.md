# Current security policy — 2026-10-20
Owner: security team. Status: authoritative.

## SECURITY-1
orders:write authorizes create. orders:read authorizes queries, counts and audit queries. fulfillment:write authorizes recovery, hold and release. billing:read alone authorizes invoice export. Never substitute a different permission because a handler is read-only.

## SECURITY-2
Authenticate and authorize before mutating any state or emitting success audit events. A foreign order ID produces NOT_FOUND. Tenant identity participates in idempotency and query filtering. Denied requests leave journal, provider and counters unchanged. Do not leak another tenant's order through invoice pagination or a permissive object lookup.
