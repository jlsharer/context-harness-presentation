# ADR-OLD-2 — prototype invoice export, 2025-10-01
Status: superseded internal experiment.

A prototype exported all tenants to a global dashboard, used orders:read and truncated floating tax fractions. Holds were process-local UI flags. None of these choices is permitted by current SECURITY-1/2, HOLDS-1/2, INVOICE-1/2/3 or AUDIT-1/2.
