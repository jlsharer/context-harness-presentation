# Current fulfillment holds — 2026-10-20
Owner: workflow team. Status: authoritative feature requirements.

## HOLDS-1
holdOrder(actor,{orderId,reason,correlationId}) returns {orderId,held:true}. Require fulfillment:write, same tenant, nonempty reason up to200 characters and correlationId of1–100 characters. A fulfilled order cannot be held (CONFLICT/409). A held order cannot dispatch, including after service restart.

## HOLDS-2
releaseOrder(actor,{orderId,correlationId}) returns {orderId,held:false}. Repeating an already-effective hold or release is a no-op; it emits no additional transition or audit event. Release does not itself send delivery; a subsequent recover may deliver exactly once. Both hold and release must persist as events and reconstruct state after restart. Concurrent calls in this in-process service must not duplicate transitions.
