# Current storage guarantees — 2026-10-20
Owner: storage team. Status: authoritative.

## STORAGE-1
A journal instance persists across simulated service restarts. appendOrder is a legacy nonunique append. commitOrder atomically enforces tenant/key uniqueness at the persistence boundary, after beforeCommit has resolved. Its returned record may be an existing committed order rather than the supplied draft. Do not assume a process-local lookup or service-instance mutex prevents races across service instances.

## STORAGE-2
failNext({key:'tenant:key',phase:'before'|'after'}) injects one deterministic failure. Before means no commit; after means commit happened but its acknowledgement was lost. Neither caller-side rejection nor a missing in-memory cache entry proves rollback. Read durable events to resolve ambiguity.

## STORAGE-3
Projection state derives from committed events. Recovery may reprocess an event multiple times. A journal record for dispatch may be missing after an external delivery; durable downstream idempotency is therefore necessary. Different order keys must make progress while one beforeCommit callback is blocked.
