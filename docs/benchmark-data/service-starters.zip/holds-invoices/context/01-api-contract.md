# Current API contract — 2026-10-20
Owner: service team. Status: authoritative internal contract.

## API-1
createService({journal,sink,clock}) returns createOrder, countOrders, listOrders, getOrder, recover, holdOrder, releaseOrder, exportInvoices and auditEvents. actor={tenantId,permissions}; all data is tenant scoped.

## API-2
createOrder(actor,{key,items:[{sku,quantity,unitCents}],taxBps?,deferFulfillment?}) returns exactly {id,tenantId,key,status:'committed',totalCents,createdAt}. Repeated tenant/key returns the first committed identity even if a different request body arrives; it must not create another durable record. Count committed orders, never attempts. IDs may have gaps. Invalid data is INVALID/400; unauthorized is FORBIDDEN/403. Foreign/missing order IDs are indistinguishable NOT_FOUND/404.

## API-3
Default create attempts fulfillment after commit. deferFulfillment:true skips initial dispatch but recovery may later dispatch it unless held. Post-commit acknowledgement failure may reject the initial call; a retry must recover the committed order and complete pending delivery. listOrders sorts by stable order ID and returns cloned DTOs. No public API field removal or changed error code is allowed.

## API-4
The thin router exposes POST/GET /orders, GET /orders/:id, POST /fulfillment/run, POST /orders/:id/hold and /release, GET /invoices. It maps service errors to their status and unexpected storage failures to STORAGE_UNAVAILABLE/503. It is an in-process HTTP-shaped adapter; no listening socket is required.
