# Operational context
Synthetic internal runbook, 2026-10-20.

## OPS-1
Run npm test from the repository root; dependencies and network are unnecessary. Simulate restart by creating another service with the same journal and sink. beforeCommit can pause one key to expose concurrency. Use fault injection rather than sleeps to model storage ambiguity.

## OPS-2
Do not rewrite the API, delete regressions or add packages. The task is the service core, not a deployment. Native CLI/MCP capabilities may supply file access, but all required task context is already in this repository. Maintain evidence anchors when composing a scoped handoff.
