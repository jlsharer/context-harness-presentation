import {createJournal} from './storage/journal.mjs';
import {createSink} from './fulfillment/sink.mjs';
import {createRepository} from './orders/repository.mjs';
import {createDispatcher} from './fulfillment/dispatcher.mjs';
import {orderCommands} from './orders/create.mjs';
import {queries} from './orders/queries.mjs';
import {createRecovery} from './fulfillment/recovery.mjs';
import {createHolds} from './fulfillment/holds.mjs';
import {createInvoices} from './billing/invoices.mjs';
import {readAudit} from './audit/events.mjs';
import {authorize} from './auth/policy.mjs';
export function createService({journal = createJournal(), sink = createSink(), clock = () => '2026-10-20T12:00:00.000Z'} = {}) {
  const repository = createRepository(journal);
  const dispatch = createDispatcher({journal, sink, repository, clock});
  const dependencies = {journal, sink, repository, dispatch, clock};
  const commands = orderCommands(dependencies), query = queries(repository);
  const holds = createHolds(dependencies);
  return {
    createOrder: commands.create, countOrders: commands.count,
    listOrders: query.list, getOrder: query.get,
    recover: createRecovery(dependencies), holdOrder: holds.hold, releaseOrder: holds.release,
    exportInvoices: createInvoices(dependencies),
    auditEvents(actor) { return readAudit(journal, authorize(actor, 'orders:read')); },
  };
}
