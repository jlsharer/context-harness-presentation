import {authorize} from '../auth/policy.mjs';
import {validateOrder} from '../domain/validation.mjs';
import {orderDto} from './dto.mjs';
import {makeAudit} from '../audit/events.mjs';
export function orderCommands({journal, repository, dispatch, clock}) {
  return {
    async create(actor, input) {
      const tenantId = authorize(actor, 'orders:write');
      const validated = validateOrder(tenantId, input);
      let order = repository.byKey(tenantId, validated.key);
      if (!order) {
        const draft = {...validated, id: journal.allocateId(), tenantId, createdAt: clock()};
        const audit = makeAudit({action: 'order.created', tenantId, subjectId: draft.id, correlationId: validated.key, at: clock()});
        order = await journal.commitOrder(draft, audit);
      }
      // A retry after a lost acknowledgement also repairs pending fulfillment.
      if (!order.deferFulfillment) await dispatch(order);
      return orderDto(order);
    },
    count(actor) {
      const tenantId = authorize(actor, 'orders:read');
      return repository.all().filter(order => order.tenantId === tenantId).length;
    },
  };
}
