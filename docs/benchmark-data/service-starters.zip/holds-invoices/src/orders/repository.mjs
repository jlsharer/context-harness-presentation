import {clone} from '../domain/keys.mjs';
export function createRepository(journal) {
  function all() {
    const byId = new Map();
    for (const event of journal.events()) {
      if (event.type === 'order.committed') byId.set(event.order.id, clone(event.order));
    }
    return [...byId.values()].sort((a, b) => a.id.localeCompare(b.id));
  }
  return {
    all,
    byId(id) { return all().find(order => order.id === id) ?? null; },
    byKey(tenantId, key) { return all().find(order => order.tenantId === tenantId && order.key === key) ?? null; },
    held(id) {
      let held = false;
      for (const event of journal.events()) {
        if (event.orderId !== id) continue;
        if (event.type === 'hold.created') held = true;
        if (event.type === 'hold.released') held = false;
      }
      return held;
    },
    fulfilled(id) { return journal.events().some(event => event.type === 'fulfillment.sent' && event.orderId === id); },
  };
}
