import {authorize} from '../auth/policy.mjs';
import {missing} from '../domain/errors.mjs';
import {orderDto} from './dto.mjs';
export function queries(repository) {
  return {
    list(actor) {
      const tenantId = authorize(actor, 'orders:read');
      return repository.all().filter(order => order.tenantId === tenantId).map(orderDto);
    },
    get(actor, id) {
      const tenantId = authorize(actor, 'orders:read');
      const order = repository.byId(id);
      if (!order || order.tenantId !== tenantId) throw missing();
      return orderDto(order);
    },
  };
}
