export function orderDto(order) {
  return {id: order.id, tenantId: order.tenantId, key: order.key,
    status: 'committed', totalCents: order.totalCents, createdAt: order.createdAt};
}
