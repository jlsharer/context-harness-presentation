import {clone, keyOf} from '../domain/keys.mjs';
// A shared journal instance represents persisted storage across service restarts.
// Order uniqueness is a storage operation, not a cache or service-instance lock.
export function createJournal({beforeCommit = async () => {}} = {}) {
  const log = [];
  const faults = [];
  let sequence = 0;
  let nextId = 0;
  const fault = (identity, phase) => {
    const index = faults.findIndex(x => x.key === identity && x.phase === phase);
    if (index >= 0) {
      faults.splice(index, 1);
      throw new Error('storage ' + phase + '-commit timeout');
    }
  };
  const append = event => {
    const stored = {...clone(event), sequence: ++sequence};
    log.push(stored);
    return clone(stored);
  };
  const getOrder = (tenantId, key) => {
    const event = log.find(e => e.type === 'order.committed' && e.order.tenantId === tenantId && e.order.key === key);
    return event ? clone(event.order) : null;
  };
  return {
    allocateId() { return 'ord-' + String(++nextId).padStart(6, '0'); },
    events() { return clone(log); },
    findOrder: getOrder,
    failNext(spec) { faults.push(clone(spec)); },
    appendEvent: append,
    async appendOrder(order, audit) {
      await beforeCommit(clone(order));
      const identity = keyOf(order.tenantId, order.key);
      fault(identity, 'before');
      append({type: 'order.committed', order, audit});
      fault(identity, 'after');
      return clone(order);
    },
    async commitOrder(order, audit) {
      await beforeCommit(clone(order));
      const identity = keyOf(order.tenantId, order.key);
      // There is no await between lookup and append: one atomic storage boundary.
      const existing = getOrder(order.tenantId, order.key);
      if (existing) return existing;
      fault(identity, 'before');
      append({type: 'order.committed', order, audit});
      fault(identity, 'after');
      return clone(order);
    },
  };
}
