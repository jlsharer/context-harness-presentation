import {ServiceError} from '../domain/errors.mjs';
export function createHolds(dependencies) {
  return {
    async hold() { throw new ServiceError('NOT_IMPLEMENTED', 'Holds not available', 501); },
    async release() { throw new ServiceError('NOT_IMPLEMENTED', 'Release not available', 501); },
  };
}
