import {clone} from '../domain/keys.mjs';
// External-effect stand-in retained across service restarts.
// send permits repeats; sendOnce is the provider's durable idempotency contract.
export function createSink() {
  const records = [];
  const keys = new Map();
  const send = order => {
    const receipt = {receiptId: 'receipt-' + (records.length + 1), orderId: order.id, tenantId: order.tenantId};
    records.push(receipt);
    return clone(receipt);
  };
  return {
    send,
    sendOnce(key, order) {
      if (keys.has(key)) return clone(keys.get(key));
      const receipt = send(order);
      keys.set(key, receipt);
      return clone(receipt);
    },
    receipts() { return clone(records); },
  };
}
