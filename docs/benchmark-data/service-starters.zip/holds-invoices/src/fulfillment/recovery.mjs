import {authorize} from '../auth/policy.mjs';
export function createRecovery({repository, dispatch}) {
  return async actor => {
    const tenantId = authorize(actor, 'fulfillment:write');
    const results = [];
    for (const order of repository.all().filter(order => order.tenantId === tenantId)) {
      const receipt = await dispatch(order);
      if (receipt) results.push(receipt);
    }
    return results;
  };
}
