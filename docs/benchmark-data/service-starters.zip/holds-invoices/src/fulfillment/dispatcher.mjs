export function createDispatcher({journal, sink, repository, clock}) {
  return async function dispatch(order) {
    if (repository.held(order.id)) return null;
    const key = order.tenantId + ':' + order.id;
    const receipt = sink.sendOnce(key, order);
    if (!repository.fulfilled(order.id)) {
      journal.appendEvent({type: 'fulfillment.sent', orderId: order.id, receipt, at: clock()});
    }
    return receipt;
  };
}
