import {ServiceError, invalid} from '../domain/errors.mjs';
import {keyOf} from '../domain/keys.mjs';
export function authorize(actor, permission) {
  if (!actor || typeof actor !== 'object') throw new ServiceError('FORBIDDEN', 'Authentication required', 403);
  keyOf(actor.tenantId, 'permission');
  if (!Array.isArray(actor.permissions) || !actor.permissions.includes(permission)) {
    throw new ServiceError('FORBIDDEN', 'Permission denied', 403);
  }
  return actor.tenantId;
}
