import {invalid} from '../domain/errors.mjs';
export function page(items, cursor = 0, limit = 20) {
  if (!Number.isInteger(cursor) || cursor < 0 || !Number.isInteger(limit) || limit < 1 || limit > 100) throw invalid('Invalid pagination');
  const selected = items.slice(cursor, cursor + limit);
  return {items: selected, nextCursor: cursor + limit < items.length ? cursor + limit : null};
}
