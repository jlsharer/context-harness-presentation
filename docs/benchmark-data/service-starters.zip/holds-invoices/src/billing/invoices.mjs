import {ServiceError} from '../domain/errors.mjs';
export function createInvoices(dependencies) {
  return async () => { throw new ServiceError('NOT_IMPLEMENTED', 'Invoice export not available', 501); };
}
