export function orderRoutes(service) {
  return async ({method, path, actor, body}) => {
    if (method === 'POST' && path === '/orders') return {status: 201, body: await service.createOrder(actor, body)};
    if (method === 'GET' && path === '/orders') return {status: 200, body: {items: service.listOrders(actor)}};
    const match = /^\/orders\/(ord-[0-9]+)$/.exec(path);
    if (method === 'GET' && match) return {status: 200, body: service.getOrder(actor, match[1])};
    return null;
  };
}
