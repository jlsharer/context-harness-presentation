export function billingRoutes(service) {
  return async ({method, path, actor, query}) => {
    if (method === 'GET' && path === '/invoices') return {status: 200, body: await service.exportInvoices(actor, query)};
    return null;
  };
}
