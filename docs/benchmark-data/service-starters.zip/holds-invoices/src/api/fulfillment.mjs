export function fulfillmentRoutes(service) {
  return async ({method, path, actor, body}) => {
    if (method === 'POST' && path === '/fulfillment/run') return {status: 200, body: {receipts: await service.recover(actor)}};
    const match = /^\/orders\/(ord-[0-9]+)\/(hold|release)$/.exec(path);
    if (method === 'POST' && match) {
      const operation = match[2] === 'hold' ? service.holdOrder : service.releaseOrder;
      return {status: 200, body: await operation(actor, {...body, orderId: match[1]})};
    }
    return null;
  };
}
