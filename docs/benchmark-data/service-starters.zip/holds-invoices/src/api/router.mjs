import {orderRoutes} from './orders.mjs';
import {fulfillmentRoutes} from './fulfillment.mjs';
import {billingRoutes} from './billing.mjs';
export function createApi(service) {
  const routes = [orderRoutes(service), fulfillmentRoutes(service), billingRoutes(service)];
  return {async handle(request) {
    try {
      for (const route of routes) {
        const response = await route(request);
        if (response) return response;
      }
      return {status: 404, body: {code: 'NOT_FOUND'}};
    } catch (error) {
      return {status: error.status ?? 503, body: {code: error.code ?? 'STORAGE_UNAVAILABLE', message: error.message}};
    }
  }};
}
