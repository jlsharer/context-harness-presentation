import {invalid} from './errors.mjs';
export function keyOf(tenantId, key) {
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(tenantId ?? '') || !/^[a-zA-Z0-9_-]{1,64}$/.test(key ?? '')) {
    throw invalid('Tenant and key must be 1–64 safe characters');
  }
  return tenantId + ':' + key;
}
export const clone = value => structuredClone(value);
