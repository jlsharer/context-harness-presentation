import {invalid} from './errors.mjs';
import {keyOf, clone} from './keys.mjs';
import {calculateTotals} from './money.mjs';
export function validateOrder(tenantId, input) {
  if (!input || typeof input !== 'object') throw invalid('Order input required');
  keyOf(tenantId, input.key);
  if (input.deferFulfillment !== undefined && typeof input.deferFulfillment !== 'boolean') throw invalid('Invalid deferFulfillment');
  const totals = calculateTotals(input.items, input.taxBps ?? 0);
  return {key: input.key, items: clone(input.items), taxBps: input.taxBps ?? 0,
    deferFulfillment: input.deferFulfillment ?? false, ...totals};
}
export function validateCorrelation(value) {
  if (typeof value !== 'string' || value.length < 1 || value.length > 100) throw invalid('Correlation ID required');
  return value;
}
