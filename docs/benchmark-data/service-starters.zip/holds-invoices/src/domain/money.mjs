import {invalid} from './errors.mjs';
export function calculateTotals(items, taxBps = 0) {
  if (!Array.isArray(items) || items.length === 0 || items.length > 100) throw invalid('Items required');
  if (!Number.isInteger(taxBps) || taxBps < 0 || taxBps > 10000) throw invalid('Invalid tax basis points');
  let subtotalCents = 0;
  for (const item of items) {
    if (typeof item.sku !== 'string' || !item.sku.length || item.sku.length > 100) throw invalid('Invalid SKU');
    if (!Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 10000) throw invalid('Invalid quantity');
    if (!Number.isInteger(item.unitCents) || item.unitCents < 0 || item.unitCents > 1000000) throw invalid('Invalid unit cents');
    subtotalCents += item.quantity * item.unitCents;
  }
  const numerator = subtotalCents * taxBps;
  if (!Number.isSafeInteger(numerator + 5000)) throw invalid('Amount exceeds safe arithmetic');
  const taxCents = Math.floor((numerator + 5000) / 10000);
  return {subtotalCents, taxCents, totalCents: subtotalCents + taxCents};
}
