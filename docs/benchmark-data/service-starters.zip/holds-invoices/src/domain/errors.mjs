export class ServiceError extends Error {
  constructor(code, message, status = 400) {
    super(message);
    this.name = 'ServiceError';
    this.code = code;
    this.status = status;
  }
}
export const invalid = message => new ServiceError('INVALID', message, 400);
export const missing = () => new ServiceError('NOT_FOUND', 'Order not found', 404);
export const conflict = message => new ServiceError('CONFLICT', message, 409);
