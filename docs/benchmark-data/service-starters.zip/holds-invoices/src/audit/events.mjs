export function makeAudit({action, tenantId, subjectId, correlationId, at}) {
  return {id: action + ':' + subjectId + ':' + correlationId, action, tenantId,
    subjectId, correlationId, outcome: 'success', at};
}
export function readAudit(journal, tenantId) {
  return journal.events().filter(event => event.audit?.tenantId === tenantId).map(event => event.audit);
}
