import { captureOutput } from './lib/bound-tool-output.mjs';
let raw = '';
try {
  for await (const chunk of process.stdin) {
    raw += chunk;
    if (raw.length > 4000000) throw Error('Hook input too large');
  }
  const event = JSON.parse(raw || '{}');
  const output = await (async () => {
    return captureOutput(event);
  })();
  process.stdout.write(typeof output === 'string' ? output : JSON.stringify(output || {}));
} catch (error) {
  process.stderr.write(
    'Context component skipped: ' +
      (error instanceof SyntaxError ? 'Invalid local JSON.' : error.message) +
      '\n',
  );
}
