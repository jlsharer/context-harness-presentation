import { validateHandoff } from '../skills/validate-worker-report/scripts/handoff.mjs';
let raw = '';
try {
  for await (const chunk of process.stdin) {
    raw += chunk;
    if (raw.length > 4000000) throw Error('Hook input too large');
  }
  const event = JSON.parse(raw || '{}');
  const output = await (async () => {
    if (event.hook_event_name !== 'PreToolUse' || event.tool_name !== 'SubagentHandback') return {};
    try {
      const message = event.tool_input?.message;
      if (typeof message === 'string' && Buffer.byteLength(message) > 12000)
        throw Error('Oversized report');
      validateHandoff(typeof message === 'string' ? JSON.parse(message) : message);
      return {};
    } catch {
      return {
        hookSpecificOutput: {
          hookEventName: 'PreToolUse',
          permissionDecision: 'deny',
          permissionDecisionReason: 'Worker report is not a valid bounded six-field handoff.',
        },
      };
    }
  })();
  process.stdout.write(typeof output === 'string' ? output : JSON.stringify(output || {}));
} catch (error) {
  process.stderr.write(
    'Context component skipped: ' +
      (error instanceof SyntaxError ? 'Invalid local JSON.' : error.message) +
      '\n',
  );
}
