let raw = '';
try {
  for await (const chunk of process.stdin) {
    raw += chunk;
    if (raw.length > 4000000) throw Error('Hook input too large');
  }
  const event = JSON.parse(raw || '{}');
  const output = await (async () => {
    if (event.hook_event_name !== 'SubagentStart') return {};
    return {
      hookSpecificOutput: {
        hookEventName: 'SubagentStart',
        additionalContext:
          'Stay within the delegated question, assigned sources and permitted actions. Return a ' +
          'bounded report: task_id, summary, source_anchors, findings, checks [{command,status}], ' +
          'open_questions. Use not-run for unexecuted checks and surface uncertainty. Coordinator ' +
          'owns source review and acceptance. This guidance grants no permissions.',
      },
    };
  })();
  process.stdout.write(typeof output === 'string' ? output : JSON.stringify(output || {}));
} catch (error) {
  process.stderr.write(
    'Context component skipped: ' +
      (error instanceof SyntaxError ? 'Invalid local JSON.' : error.message) +
      '\n',
  );
}
