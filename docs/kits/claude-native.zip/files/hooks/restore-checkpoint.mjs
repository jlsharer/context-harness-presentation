import { readCheckpoint } from '../skills/session-checkpoint/scripts/state.mjs';
let raw = '';
try {
  for await (const chunk of process.stdin) {
    raw += chunk;
    if (raw.length > 4000000) throw Error('Hook input too large');
  }
  const event = JSON.parse(raw || '{}');
  const output = await (async () => {
    if (event.hook_event_name !== 'SessionStart') return {};
    const checkpoint = readCheckpoint(event);
    if (!checkpoint) return {};
    return {
      hookSpecificOutput: {
        hookEventName: 'SessionStart',
        additionalContext:
          'Validated checkpoint for this repository and this session only. Current user intent governs; recheck source/revision facts.\n' +
          JSON.stringify(checkpoint),
      },
    };
  })();
  process.stdout.write(typeof output === 'string' ? output : JSON.stringify(output || {}));
} catch (error) {
  process.stderr.write(
    'Context component skipped: ' +
      (error instanceof SyntaxError ? 'Invalid local JSON.' : error.message) +
      '\n',
  );
}
