let raw = '';
try {
  for await (const chunk of process.stdin) {
    raw += chunk;
    if (raw.length > 4000000) throw Error('Hook input too large');
  }
  const event = JSON.parse(raw || '{}');
  const output = await (async () => {
    if (event.hook_event_name !== 'PreCompact') return {};
    return (
      'Preserve the current user goal, applicable constraints, source/revision anchors, ' +
      'decisions, unfinished work and required checks in the compaction summary. Keep pending ' +
      'checks incomplete. If a validated session checkpoint already exists, preserve its path. ' +
      'This hook supplies summary instructions; it does not author or save factual checkpoint state.'
    );
  })();
  process.stdout.write(typeof output === 'string' ? output : JSON.stringify(output || {}));
} catch (error) {
  process.stderr.write(
    'Context component skipped: ' +
      (error instanceof SyntaxError ? 'Invalid local JSON.' : error.message) +
      '\n',
  );
}
