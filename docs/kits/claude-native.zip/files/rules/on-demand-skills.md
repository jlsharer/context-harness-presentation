# Load the procedure needed for this stage

Use installed skill names/descriptions to choose relevant capabilities. Load a full skill only when its triggering conditions match the current task, then read only the supporting references needed for that stage. Explicit /skill-name invocation selects a procedure directly. Do not open every installed skill, tool description or repository document at kickoff. Reassess source scope when the task changes. Skill instructions do not grant tool, edit, push or deployment permissions.
