# Preserve useful reusable prefixes

When assembling requests you control, keep stable instructions, tool definitions and reusable reference blocks stable and place variable task content after the reusable prefix where the provider supports this. Preserve semantic ordering and native instruction precedence; do not reorder a native harness blindly. Route requests by task suitability, not cache price alone.

Cache reads still occupy model input. A shared prefix is only a candidate hit: provider/model, routing, TTL, minimum length and exact request serialization affect reuse. Use real usage fields to distinguish fresh input, cache writes, reads and output; missing fields stay unknown. Validate quality, latency and total cost per accepted task before adopting a policy. This rule does not configure provider caches.
