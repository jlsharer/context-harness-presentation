# Task and evidence contract

For a multi-step task, keep the current goal, applicable constraints, allowed changes and acceptance checks explicit. Reconfirm after a scope change. Repository-specific instructions and current user intent remain relevant; this rule grants no permissions.

For QA defect work, distinguish product, test/fixture and environment hypotheses before choosing the repair layer. Link consequential claims to sources and actual results. Required local and CI checks must concern the target revision; pending, inaccessible and not-run checks remain incomplete. A passing retry or schema validator does not prove a fix. Preserve unfinished work at handoff and use existing authorization for external actions.
