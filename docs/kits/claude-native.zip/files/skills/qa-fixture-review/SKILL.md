---
name: qa-fixture-review
description: Use when parallel or order-dependent tests suggest shared mutable fixtures, cleanup collisions or cross-test data leakage.
---

# Fixture isolation review

## Input contract

Failing test/revision, fixture setup/teardown sources, worker topology and isolated-versus-parallel evidence.

## Review

1. Map resource ownership: who creates each user/cart/session, who mutates it and who cleans it up?
2. Identify shared IDs, static/global state, worker-scoped resources and cleanup that can affect another test.
3. Compare the fixture contract with product behavior before deciding which layer is defective.
4. Propose a deterministic competing-operation regression. A sleep or retry increase alone is not an evidence-based isolation fix.
5. Recommend the narrowest ownership change, including teardown safety and remaining risks.

## Output

Source-linked ownership table, candidate race/interference, counterevidence, proposed regression and unresolved questions. For delegated delivery use the installed six-field handoff contract and its byte bound. Report checks as passed, failed or not-run with actual evidence references in findings/source anchors.

## Limits

Review is read-only unless the task explicitly authorizes edits. Do not infer tenant/security correctness from fixture isolation alone. Do not claim the test is universally flake-free.

## Operating resources and first-use setup

Before acting in a new repository, read [repository-setup.md](references/repository-setup.md) to bind actual commands, revision identity, allowed paths and CI tooling. Use native discovery appropriate to the harness: Claude slash invocation, Codex dollar skill mention, or the delivered OpenCode command/skill. If a required tool or permission is unavailable, report the gap; do not invent an execution result.

Use the [task and report contracts](references/contracts.md) and supplied [task](assets/task.json) / [report](assets/report.json) drafts. Replace draft markers and required checks before assessment. From this skill's directory, inspect `node "${CLAUDE_SKILL_DIR}/scripts/qa.mjs" --help`, then run the helpers using quoted absolute paths as needed. This skill carries its own helpers; it does not require a project framework.

```sh
node "${CLAUDE_SKILL_DIR}/scripts/qa.mjs" validate-task /path/to/task.json
node "${CLAUDE_SKILL_DIR}/scripts/qa.mjs" validate-report /path/to/report.json
node "${CLAUDE_SKILL_DIR}/scripts/qa.mjs" assess /path/to/report.json --task /path/to/task.json
node "${CLAUDE_SKILL_DIR}/scripts/qa.mjs" handoff /path/to/report.json --task /path/to/task.json
```

Assessment binds required checks to the reviewed task. Exit 2 means declared evidence is incomplete; the helper does not run commands, authenticate, fetch CI, grant permission or establish factual truth. A wrong-revision result cannot become a passed check for the target in the bounded handoff. Reopen actual source/results when reviewing consequential claims.

## Read only the reference for this stage

- [fixture-isolation.md](references/fixture-isolation.md): ownership ledger and discriminating parallel checks.
- [diagnosis.md](references/diagnosis.md): counterevidence before choosing a repair layer.

Before broad rollout, use [evaluation.md](references/evaluation.md) to test representative tasks, model suitability, actual native integration and accepted-task results. [provenance.md](references/provenance.md) records the published authoring patterns used; this package is original and carries no vendor certification.

## Two different report operations

Use scripts/qa.mjs with the full QA report and reviewed task to assess required-check coverage or generate a bounded handoff. A returned six-field worker report is validated directly with scripts/handoff.mjs; do not pass it as a full QA report. All helper paths belong to this skill and remain usable after the download is deleted. Commands in reference pages are relative to this skill directory; use the resolved absolute script path from a repository.
