import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const text = (value, name, max = 20000) => {
  if (typeof value !== 'string' || !value.trim() || value.length > max)
    throw Error(name + ' must be a nonempty string ≤ ' + max + ' characters');
  return value;
};

const strings = (value, name, nonempty = true) => {
  if (!Array.isArray(value) || (nonempty && !value.length) || value.length > 50)
    throw Error(name + ' must be an array' + (nonempty ? ' with entries' : ''));
  return value.map((v) => text(v, name, 2000));
};

export function buildPacket(input) {
  text(input.goal, 'goal');
  const constraints = strings(input.constraints, 'constraints'),
    checks = strings(input.checks, 'checks');
  if (!Array.isArray(input.sources) || !input.sources.length) throw Error('sources required');
  const body = [
    '# Current goal\n' + input.goal,
    '# Constraints\n' + constraints.join('\n'),
    '# Selected sources\n' +
      input.sources
        .map(
          (s) =>
            '## ' + text(s.path, 'source path', 500) + '\n' + text(s.text, 'source body', 1000000),
        )
        .join('\n\n'),
    '# Acceptance checks\n' + checks.join('\n'),
  ].join('\n\n');
  return {
    text: body,
    bytes: Buffer.byteLength(body),
    scope: 'Complete supplied text; byte count is not native tokens.',
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const input = process.argv[2];
    if (!input || fs.statSync(input).size > 1024 * 1024)
      throw Error('Supply a bounded local JSON file');
    console.log(JSON.stringify(buildPacket(JSON.parse(fs.readFileSync(input, 'utf8'))), null, 2));
  } catch (error) {
    console.error(error instanceof SyntaxError ? 'Invalid local JSON.' : error.message);
    process.exitCode = 1;
  }
}
