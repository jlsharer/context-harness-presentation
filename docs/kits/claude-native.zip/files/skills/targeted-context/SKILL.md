---
name: targeted-context
description: Use when a task needs a focused packet of selected source evidence before broader repository exploration.
---

# Targeted source packet

## Use when

Initial context is broad, or the next investigation question needs a specific fact.

## Inputs and prerequisites

Goal, constraints, acceptance checks and selected source paths/full excerpts.

Delivered mechanism: **Packet helper**. Native integrations are selected per harness; portable guidance does not imply automatic native enforcement.

## Procedure

1. Start from the failing assertion, owning fixture and relevant product contract. Record source anchors and what is still unknown.
2. Build packet JSON with goal, constraints, checks and sources [{path,text}]. Use existing repository evidence rather than inventing file names.
3. Run node scripts/packet.mjs input.json; admit the selected packet, not an entire repository dump.
4. Expand only for a discriminating unanswered question. Keep the source version/revision with the evidence.

## Output contract

A focused packet and traceable source scope. The helper reports bytes, not provider-native tokens.

## Verification and evaluation

Inspect required-fact coverage and source fidelity. Compare included input and accepted-task outcomes on representative work.

## Limits and recovery

Narrowing input can omit a critical dependency. Reopen anchors when conclusions conflict; the helper does not discover relevance or prove completeness. Preserve existing unrelated files/hooks and enterprise settings. If a managed file differs, review it rather than overwriting. Keep task evidence until the project's retention/acceptance requirements permit removal.

## References

- [Native hook capabilities](https://code.claude.com/docs/en/hooks)
- [Skill loading and resources](https://code.claude.com/docs/en/skills)
- [Claude skills](https://code.claude.com/docs/en/skills)


## Native operation

This is an independent personal skill. Invoke /targeted-context; no shared menu or index is needed. From this skill directory run the command below, or use its resolved absolute path while working in the repository:

```sh
node "${CLAUDE_SKILL_DIR}/scripts/packet.mjs" /absolute/input.json
```

Input is goal, constraints[], checks[] and sources[{path,text}]. Select complete relevant excerpts with source anchors; do not use the helper to ingest the entire repository. It constructs a packet and reports UTF-8 bytes, not native token usage. It does not fetch files or call a model. Review required-fact coverage before admitting the packet.

