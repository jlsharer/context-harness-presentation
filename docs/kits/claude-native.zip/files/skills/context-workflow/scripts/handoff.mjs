import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const text = (value, name, max = 20000) => {
  if (typeof value !== 'string' || !value.trim() || value.length > max)
    throw Error(name + ' must be a nonempty string ≤ ' + max + ' characters');
  return value;
};

const strings = (value, name, nonempty = true) => {
  if (!Array.isArray(value) || (nonempty && !value.length) || value.length > 50)
    throw Error(name + ' must be an array' + (nonempty ? ' with entries' : ''));
  return value.map((v) => text(v, name, 2000));
};

export function validateHandoff(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input))
    throw Error('handoff object required');
  const allowed = ['task_id', 'summary', 'source_anchors', 'findings', 'checks', 'open_questions'];
  if (Object.keys(input).some((k) => !allowed.includes(k))) throw Error('Unknown handoff field');
  if (Buffer.byteLength(JSON.stringify(input), 'utf8') > 12000)
    throw Error('Handoff exceeds 12000 serialized UTF-8 bytes');
  text(input.task_id, 'task_id', 200);
  text(input.summary, 'summary', 2000);
  strings(input.source_anchors, 'source_anchors');
  strings(input.findings, 'findings');
  strings(input.open_questions, 'open_questions', false);
  if (!Array.isArray(input.checks) || !input.checks.length || input.checks.length > 30)
    throw Error('checks required');
  for (const c of input.checks) {
    if (
      !c ||
      typeof c !== 'object' ||
      Array.isArray(c) ||
      Object.keys(c).some((k) => !['command', 'status'].includes(k))
    )
      throw Error('Unknown check field');
    text(c.command, 'check command', 500);
    if (!['passed', 'failed', 'not-run'].includes(c.status))
      throw Error('check status must be passed, failed or not-run');
  }
  return input;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const input = process.argv[2];
    if (!input || fs.statSync(input).size > 1024 * 1024)
      throw Error('Supply a bounded local JSON file');
    console.log(
      JSON.stringify(validateHandoff(JSON.parse(fs.readFileSync(input, 'utf8'))), null, 2),
    );
  } catch (error) {
    console.error(error instanceof SyntaxError ? 'Invalid local JSON.' : error.message);
    process.exitCode = 1;
  }
}
