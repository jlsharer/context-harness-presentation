import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const text = (value, name, max = 20000) => {
  if (typeof value !== 'string' || !value.trim() || value.length > max)
    throw Error(name + ' must be a nonempty string ≤ ' + max + ' characters');
  return value;
};

const strings = (value, name, nonempty = true) => {
  if (!Array.isArray(value) || (nonempty && !value.length) || value.length > 50)
    throw Error(name + ' must be an array' + (nonempty ? ' with entries' : ''));
  return value.map((v) => text(v, name, 2000));
};

export function validateCheckpoint(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input))
    throw Error('checkpoint required');
  if (
    Object.keys(input).some(
      (key) =>
        !['goal', 'constraints', 'source_anchors', 'open_work', 'acceptance_checks'].includes(key),
    )
  )
    throw Error('Unknown checkpoint field');
  text(input.goal, 'goal');
  for (const key of ['constraints', 'source_anchors', 'acceptance_checks'])
    strings(input[key], key);
  strings(input.open_work, 'open_work', false);
  return input;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const input = process.argv[2];
    if (!input || fs.statSync(input).size > 1024 * 1024)
      throw Error('Supply a bounded local JSON file');
    console.log(
      JSON.stringify(validateCheckpoint(JSON.parse(fs.readFileSync(input, 'utf8'))), null, 2),
    );
  } catch (error) {
    console.error(error instanceof SyntaxError ? 'Invalid local JSON.' : error.message);
    process.exitCode = 1;
  }
}
