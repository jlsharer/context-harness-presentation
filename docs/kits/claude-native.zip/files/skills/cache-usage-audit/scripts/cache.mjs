import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';

export function auditCache({ provider, usage = {}, before = '', now = '', observedTotal = null }) {
  const num = (v) => (Number.isFinite(v) && v >= 0 ? v : null);

  let total = null,
    read = null,
    write = null,
    fresh = null;
  if (provider === 'openai') {
    total = num(usage.input_tokens);
    read = num(usage.input_tokens_details?.cached_tokens);
    write = num(usage.input_tokens_details?.cache_write_tokens);
    if (total !== null && read !== null && write !== null) fresh = total - read - write;
  } else if (provider === 'anthropic') {
    fresh = num(usage.input_tokens);
    read = num(usage.cache_read_input_tokens);
    write = num(usage.cache_creation_input_tokens);
    if ([fresh, read, write].every((v) => v !== null)) total = fresh + read + write;
  } else if (provider === 'gemini') {
    total = num(observedTotal);
    read = num(usage.total_cached_tokens);
  } else throw Error('provider must be openai, anthropic or gemini');
  if (fresh !== null && fresh < 0) throw Error('Inconsistent usage partitions');
  let common = 0;
  while (common < Math.min(before.length, now.length) && before[common] === now[common]) common++;
  return {
    provider,
    total,
    read,
    write,
    fresh,
    identicalPrefixCharacters: common,
    prefixBeforeSha256: createHash('sha256').update(before).digest('hex'),
    prefixNowSha256: createHash('sha256').update(now).digest('hex'),
    scope:
      'Missing fields stay unknown (null). Character prefix is not a cache-token count or guaranteed hit. Read tokens remain included input.',
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const input = process.argv[2];
    if (!input || fs.statSync(input).size > 1024 * 1024)
      throw Error('Supply a bounded local JSON file');
    console.log(JSON.stringify(auditCache(JSON.parse(fs.readFileSync(input, 'utf8'))), null, 2));
  } catch (error) {
    console.error(error instanceof SyntaxError ? 'Invalid local JSON.' : error.message);
    process.exitCode = 1;
  }
}
